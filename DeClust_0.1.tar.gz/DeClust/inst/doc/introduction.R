## ----message=FALSE-------------------------------------------------------
library("DeClust");
data(exprM)
exprM[1:10,1:5];

## ----eval=FALSE, message=FALSE,results='hide',warning=FALSE--------------
#  r<-deClustFromMarkerlognormal(exprM,3)
#  

## ------------------------------------------------------------------------
data(r)
table(r$subtype)
r$subtype[1:10]
r$subtypeprofileM[1:10,]
r$subtypefractionM[1:10,]

## ----eval=FALSE, message=FALSE,results='hide',warning=FALSE--------------
#  BIC<-sapply(2:5,function(subtypeN)calculateBIC(exprM,deClustFromMarkerlognormal(exprM,subtypeN)))
#  plot(2:5, BIC,xlab="subtypeN",type="b")

## ------------------------------------------------------------------------
names(TCGAdeClustsubtype)
TCGAdeClustsubtype[["BLCA"]][1:10]


## ------------------------------------------------------------------------
dim(TCGAdeClustprofileM)
TCGAdeClustprofileM[1:10,1:5]


